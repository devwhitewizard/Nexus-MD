const { DataTypes } = require('sequelize');
const { sequelize } = require('../nexus/db');

let SettingsDB = null;

if (sequelize) {
    SettingsDB = sequelize.define('settings', {
        // 1. Bot Mode
        publicMode: { type: DataTypes.BOOLEAN, defaultValue: true },
        
        // 2. Automation Toggles
        antiLink: { type: DataTypes.BOOLEAN, defaultValue: false },
        antiTag: { type: DataTypes.BOOLEAN, defaultValue: false },
        antiBadword: { type: DataTypes.BOOLEAN, defaultValue: false },
        antiSpam: { type: DataTypes.BOOLEAN, defaultValue: true },
        antiDelete: { type: DataTypes.BOOLEAN, defaultValue: true },
        antiEdit: { type: DataTypes.BOOLEAN, defaultValue: true },
        antiCall: { type: DataTypes.BOOLEAN, defaultValue: false },

        statusAntiDelete: { type: DataTypes.BOOLEAN, defaultValue: false },
        autoDelete: { type: DataTypes.BOOLEAN, defaultValue: false },
        autoDeleteTime: { type: DataTypes.INTEGER, defaultValue: 30000 },
        
        // 3. Status/Presence Expansion
        autoViewStatus: { type: DataTypes.BOOLEAN, defaultValue: true },
        autoLikeStatus: { type: DataTypes.BOOLEAN, defaultValue: true },
        autoReplyStatus: { type: DataTypes.BOOLEAN, defaultValue: false },
        statusReplyText: { type: DataTypes.STRING, defaultValue: 'Nice status! ✨' },
        statusLikeEmojis: { type: DataTypes.STRING, defaultValue: '❤️,✨,🔥,🙌,👍,⭐,💥,🎉,💯,😎,🤩,😍,👏' },
        autoRead: { type: DataTypes.BOOLEAN, defaultValue: false },
        autoType: { type: DataTypes.BOOLEAN, defaultValue: false },
        autoRecord: { type: DataTypes.BOOLEAN, defaultValue: false },
        alwaysOnline: { type: DataTypes.BOOLEAN, defaultValue: false },
        autoBio: { type: DataTypes.BOOLEAN, defaultValue: false },
        
        // 4. Presence & AI
        dmPresence: { type: DataTypes.BOOLEAN, defaultValue: false },
        groupPresence: { type: DataTypes.BOOLEAN, defaultValue: false },
        chatbotAI: { type: DataTypes.BOOLEAN, defaultValue: false },
        greetDM: { type: DataTypes.BOOLEAN, defaultValue: false },
        greetDMMsg: { type: DataTypes.STRING, defaultValue: 'Hello World' },
        autoReactDM: { type: DataTypes.BOOLEAN, defaultValue: false },
        autoReactGrp: { type: DataTypes.BOOLEAN, defaultValue: false },
        
        // 5. Group Events (Welcome/Goodbye)
        welcome: { type: DataTypes.BOOLEAN, defaultValue: false },
        goodbye: { type: DataTypes.BOOLEAN, defaultValue: false },
        welcomeMsg: { 
            type: DataTypes.TEXT, 
            defaultValue: 'Hi @user, welcome to *@group*! 👋' 
        },
        goodbyeMsg: { 
            type: DataTypes.STRING, 
            defaultValue: 'Goodbye @user, we hope to see you back soon! 😢' 
        },

        // 6. Custom Content
        antiDeleteNotification: { 
            type: DataTypes.STRING, 
            defaultValue: '🕵️ *Nexus Anti-Delete Update*' 
        },
        footer: { type: DataTypes.STRING, defaultValue: '© Nexus-MD • Channel: https://whatsapp.com/channel/0029VbD62UY7IUYU6cftzu02' },
        ownerNumber: { type: DataTypes.STRING, defaultValue: '' },
        lockedCommands: { type: DataTypes.TEXT, defaultValue: '' },
        botName: { type: DataTypes.STRING, defaultValue: 'Nexus-MD' },
        device: { type: DataTypes.STRING, defaultValue: 'Android' },
        prefix: { type: DataTypes.STRING, defaultValue: '.' },
        packName: { type: DataTypes.STRING, defaultValue: 'Nexus-MD' },
        author: { type: DataTypes.STRING, defaultValue: 'White Wizard' },
        timezone: { type: DataTypes.STRING, defaultValue: 'Africa/Nairobi' },
        botImage: { type: DataTypes.STRING, defaultValue: 'Default' },
        hideViewChannel: { type: DataTypes.BOOLEAN, defaultValue: false },
        menuStyle: { type: DataTypes.INTEGER, defaultValue: 2 },
        antiLinkGlobal: { type: DataTypes.STRING, defaultValue: 'off' },
        antiLinkLimit: { type: DataTypes.INTEGER, defaultValue: 3 },
        antiStatusMentionGlobal: { type: DataTypes.STRING, defaultValue: 'off' },
        antiStatusMentionLimit: { type: DataTypes.INTEGER, defaultValue: 3 },
        groupEventsGlobal: { type: DataTypes.BOOLEAN, defaultValue: false },
        eventsPromote: { type: DataTypes.BOOLEAN, defaultValue: false }
    }, {
        timestamps: true
    });
}

/**
 * Initializes the settings record if it doesn't exist
 */
const getBotSettings = async () => {
    const { isOnline } = require('../nexus/db');
    const jsonStore = require('../nexus/jsonStore');
    const { defaultSettings } = require('../lib/settings');

    const defaults = defaultSettings;

    if (!isOnline() || !SettingsDB) {
        const [settings] = await jsonStore.findOrCreate({
            where: { id: 1 },
            defaults
        });
        return settings;
    }

    try {
        const [settings] = await SettingsDB.findOrCreate({
            where: { id: 1 },
            defaults
        });
        // Sync SQLite settings into jsonStore for failover protection
        jsonStore.set("settings_1", settings.dataValues || settings, true);
        return settings;
    } catch (e) {
        console.error("❌ getBotSettings Fallback:", e.message);
        // Emergency fallback to JSON store if DB sync/find fails
        const [settings] = await jsonStore.findOrCreate({ where: { id: 1 }, defaults });
        return settings;
    }
};

module.exports = { 
    SettingsDB, 
    getBotSettings,
    initSettingsDB: async () => { if(SettingsDB) await SettingsDB.sync() }
};
